
<div class="wrap">
    <div id="icon-options-general" class="icon32 icon32_adv" style="background: transparent url(<?php echo ICL_PLUGIN_URL; ?>/res/img/icon_adv.png) no-repeat;"><br /></div>
    <h2><?php _e('Support', 'sitepress') ?></h2>
<?php do_action('icl_support_admin_page'); ?>
</div>