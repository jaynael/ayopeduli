<?php
if($sitepress_settings['existing_content_language_verified']){
    $WPML_Packages = new WPML_Packages();
}
?>
