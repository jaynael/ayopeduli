= Is s2Member compatible with WordPress Multisite Networking? =
Yes. s2Member and s2Member Pro are both compatible with Multisite Networking. After you enable Multisite Networking, install the s2Member plugin. Then navigate to `s2Member -› Multisite (Config)` in the Dashboard on your Main Site. You can get started now, by turning on [Multisite Networking](http://codex.wordpress.org/Create_A_Network) inside your installation of WordPress®.

You can learn more about s2Member® at [s2Member.com](http://www.s2member.com/).