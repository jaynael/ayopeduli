<?php get_header(); ?>
	<div id="content">
    	<div class="wrapper content-home">
       		<div class="top">
            	<div class="ads-left">
                	<a href="<?php // echo esc_url( home_url( '/beriklan' ) ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/YOT-banner-atas.gif" alt="" /></a>
                </div><!--end ads-left-->
        		<div id="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" /></a><span>Beta</span></div>
				<div class="ads-right">
                	<a target="_new" href="http://optikseis.com"><img src="<?php echo get_template_directory_uri(); ?>/banner/FA_banner.jpg" width="430px" alt="optic seis" /></a>
                </div>
                <div class="clearfix"></div>
            </div><!--end top-->
            <div id="wookmark">
        	<ul id="tiles">         
			   <?php  // the Loop
                while (have_posts()):
				 the_post(); 
				 global $more;
					$more = 0;?>
                	<li>
                        <div class="content-li">
							 <?php if ( in_category( array( 'sobat' ) )) { ?>	
                             <div class="sobat-ribbon">
                                    <h3>Sobat</h3>
                                </div><!--end .sobat-ribbon-->
                             <?php } ?>                        	
                            <div class="image">                            
                            <?php 				
									
									if(has_post_thumbnail()) { ?>
										<a href="<?php the_permalink(); ?>" > <?php the_post_thumbnail('post-item');?></a>
									<?php } else { ?>
                                    	<a href="<?php the_permalink(); ?>" > <?php echo '<img src="'.get_bloginfo("template_url").'/images/img-default.png" />'; ?> </a>
										<!--//echo '<img src="'.get_bloginfo("template_url").'/images/img-default.png" />';-->
									<?php }
									?>
                            		<a href="<?php the_permalink(); ?>" class="name"><?php the_title(); ?></a>
                                </div>
                                <!--<div class="date"><span>1</span>April - 2011</div>-->
                                <div class="tooltips">                                                                     	
                                   	<p class="description"><?php 
																	
                    				the_content( 'Read the full post »' ); 
									 //$shortpost = substr(the_content('','',FALSE),0,50);
									//echo $shortpost; if (strlen($shortpost) >29){ echo '&hellip;'; }
									 ?> <a href="<?php the_permalink(); ?>">Selengkapnya</a></p>
                                     <div class="donate">
                                     <?php if ( in_category( array( 'sobat', 'yayasan', 'program' ) )) { ?>												
                                    	<div class="total"><p>
                                        <?php $key = "donasi";
											$donasi = get_post_meta($post->ID, $key, true);
											if (!$donasi){
											echo "Rp.0";
											}else{
											echo "Rp. $donasi ";
											}
										?>                               
                                        
                                        </p>Terkumpul </div>
                                        <a class="tombol" href="<?php the_permalink(); ?>"> Donasi</a>
                                        <div class="clearfix"></div>
											<?php } //elseif ( in_category('blog','Uncategorized') ) {
											//echo 'none';
										//} ?>
                                      </div>
                                        <div class="author">
                                        	<div class="images">
                                            <?php
												/*if (function_exists('get_avatar')) {
												  echo get_avatar($email);
											   } else {
												  //alternate gravatar code for < 2.5
												  $grav_url = "http://www.gravatar.com/avatar/" . 
													 md5(strtolower($email)) . "?d=" . urlencode($default) . "&s=" . $size;
												  echo "<img src='$grav_url'/>";
											   }*/
											    echo get_avatar(get_the_author_meta('user_email'), 30);
											?>
                                        		<!--<img src="http://graph.facebook.com/765838607/picture?type=square" />-->
                                            </div>
                                            <div> oleh volunteer  <?php //$author = get_the_author(); 
												echo get_the_author_link(); ?>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                </div>
                            </div>
                        </li>
                       
                <?php // the_post();
                    //the_content( 'Read the full post »' );
					
                endwhile;
                ?>
                
                        <div class="clearfix"></div>
                        
                      </ul>
                      
                      </div>
                <?php twentyeleven_content_nav( 'nav-below' ); ?>
                <div class="sponsor">
                    <h2>Operational Partners </h2>
                    <div class="content-sponsor">                        
                        <div class="item-sponsor">
                            <a href="http://optikseis.com" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/images/optic-seis.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/images/logo-tim.png" /></a>
                        </div>
                        <!--<div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>-->
                        <div class="clearfix"></div>
                    </div><!--end content-sponsor-->                
                </div><!--end sponsored-->
                <div class="sponsor community">
                    <h2>Media & Community Partners </h2>
                    <div class="content-sponsor">
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://3littleangels.com" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/images/3littleangels.png" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://eryepeduli.com" target="_new"><img src="<?php echo get_template_directory_uri(); ?>/images/eryepeduli.png" /></a>
                        </div>
                        <!--<div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>
                        <div class="item-sponsor">
                            <a href="http://youngontop.com" target="_new"><img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-snc7/s160x160/423969_437751772942668_1260977220_a.jpg" /></a>
                        </div>-->
                        <div class="clearfix"></div>
                    </div><!--end content-sponsor-->                
                </div><!--end sponsored-->             	
        </div><!--end wrapper-->
    </div><!--end content-->
    
    
    <?php get_footer();?>
