<div class="contact">
    <div id="node"></div>
    <div id="success">Thank you</div>
  <h2>contact us</h2>
  <form name="contact_form" id="contact_form">
    <input type="text" name="name" id="name" value="" placeholder="Name*"/>
    <input type="text" name="organization" id="organization" value="" placeholder="organization*"/>
    <input type="text" name="phone" id="phone" value="" placeholder="Phone*"/>
    <input type="text" name="email" id="email" value="" placeholder="Email*"/>
    <textarea id="message" name="message" placeholder="Message"></textarea>
    <label for="require" id="require" class="left">* Wajib diisi</label>
    <input type="submit" value="Submit" id="send" class="right" />
    <div class="clear"></div><!--end of clear-->
  </form>
 </div><!--end of contact -->