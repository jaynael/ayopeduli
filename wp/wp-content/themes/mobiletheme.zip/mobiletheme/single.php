<?php get_header(); ?> 
             
        <div class="entry"> 
        

                                <div id="container">
                    
                                    <?php if(have_posts()) : ?>
                                    <?php while(have_posts()) : the_post(); ?>
                    
                                        <div class="post" id="post-<?php the_ID(); ?>">


                                            <div class="title">
                                                <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                                <div class="content"><?php the_content(); ?></div>
                                            </div>    
                                            
                                            <div class="date">
                                                Posted on <?php the_time('F j, Y') ?>
                                            </div>     
                                              	
                    <br clear="all" />
                    <?php comments_template(); ?>
                                        </div>                    
                    
                                    <?php endwhile; ?>
                   
                                    <?php endif; ?>
                                    
                                </div>
         
        
        </div> <!--entry-->
        
  
        <?php get_sidebar(); ?>

        <?php get_footer(); ?>        