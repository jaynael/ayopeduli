	
    	<div id="footer">     
                       
                    	<div class="copyright">Copyright &#169; <?php print(date(Y)); ?> <?php bloginfo('name'); ?> | Moblog by <a href="http://www.blogohblog.com/" title="Premium WordPress Themes">Blog Oh! Blog</a></div> 
               
        </div>
        
	</div>
    
    <?php wp_footer(); ?>

</body>
</html>