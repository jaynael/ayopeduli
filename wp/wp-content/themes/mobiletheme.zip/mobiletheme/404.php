<?php get_header(); ?> 
             
        <div class="entry"> 
        

                                <div id="container">
                    
<h2>Error 404! Page not found!</h2><br /><br />
                                    
                                </div>
         
        
        </div> <!--entry-->
        
  
        <?php get_sidebar(); ?>

        <?php get_footer(); ?>        