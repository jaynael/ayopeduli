	
    	<div id="footer">     
                       
                    	<div class="copyright">Copyright &#169; <?php print(date(Y)); ?> <?php bloginfo('name'); ?> </div> 
               
        </div>
        
	</div>
    
    <?php // wp_footer(); ?>

</body>
</html>