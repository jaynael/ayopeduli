			</div> <!-- end #main-top-shadow -->
		</div> <!-- end #main -->

		<footer id="main_footer">
			<?php do_action( 'et_mobile_footer' ); ?>
		</footer>
	</div> <!-- end #container -->
	
	<?php wp_footer(); ?>
</body>
</html>